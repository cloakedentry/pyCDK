# modules/container_escape.py
import os

def check_escape_method(method):
    if method == "hostpath":
        check_host_mount()
    else:
        print(f"Method '{method}' not supported. Try '--method hostpath'.")

def check_host_mount():
    print("Checking for host mount paths...")
    paths = ["/host", "/mnt", "/proc/1/root", "/var/lib/docker"]

    for path in paths:
        if os.path.exists(path):
            print(f"[+] {path} exists")
            try:
                contents = os.listdir(path)
                print(f"    Contents: {contents[:5]}{' ...' if len(contents) > 5 else ''}")
            except Exception as e:
                print(f"    Could not list contents: {e}")
        else:
            print(f"[-] {path} not found")
