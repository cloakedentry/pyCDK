from kubernetes import client, config
from tabulate import tabulate
import csv
import pprint

def list_privileged_pods(export_csv=False, namespace=None, show_risk=False, show_image=False):
    try:
        config.load_kube_config()
        v1 = client.CoreV1Api()
        outputlist = []

        currentContext = config.list_kube_config_contexts()[1].get("name")

        if namespace:
            pods = v1.list_namespaced_pod(namespace).items
        else:
            pods = v1.list_pod_for_all_namespaces().items

        for pod in pods:
            for container in pod.spec.containers:
                if container.security_context and container.security_context.privileged:
                    risk = "HIGH" if container.security_context.privileged else "LOW"
                    image = container.image if show_image else "-"
                    outputlist.append([container.name, pod.metadata.name, pod.metadata.namespace, risk if show_risk else "-", image])

        headers = ["Container", "Pod", "Namespace"]
        if show_risk:
            headers.append("Risk")
        if show_image:
            headers.append("Image")

        print("\nPrivileged Containers:")
        print(tabulate(outputlist, headers=headers))

        if export_csv and outputlist:
            _export_csv(outputlist, currentContext)

    except Exception as e:
        print(f"Error listing privileged pods: {e}")

def _export_csv(data, context):
    MFID = 'M:c05d5e75-b600-4ebb-a139-d5a097a3adba'
    InstanceName = 'Weak Configuration - Containers Running as Privileged - Kubernetes'
    headers = ['FindingTemplateSourceIdentifier', 'FindingName', 'AssetName', 'VerificationCaption01', 'VerificationText01', 'VerificationCaption02', 'VerificationText02']
    outputFormatted = pprint.pformat(data, width=120)

    with open("./privilegedContainers.csv", "w") as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(headers)
        writer.writerow([
            MFID,
            InstanceName,
            context,
            "Use `kubectl describe pod` to view privileged flag.",
            "<<REMOVE>>",
            "The following containers are privileged.",
            outputFormatted
        ])
