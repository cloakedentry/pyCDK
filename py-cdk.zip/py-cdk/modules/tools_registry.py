def list_available_tools():
    tools = {
        "ps": "Show process info (like ps -ef)",
        "vi": "Edit files inside container",
        "ifconfig": "Display network interfaces",
        "kcurl": "Query K8s API from within container",
        "ectl": "Enumerate etcd keys (unauthorized)",
        "probe": "Scan IP and ports inside container",
    }

    for name, desc in tools.items():
        print(f"  {name:<15} - {desc}")
