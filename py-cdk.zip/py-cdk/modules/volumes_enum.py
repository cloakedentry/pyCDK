# modules/volumes_enum.py
import os
from datetime import datetime

def list_mounted_volumes(custom_paths=None):
    print("Checking mount points and volume paths:\n")

    default_paths = [
        "/mnt",
        "/media",
        "/host",
        "/var/lib/kubelet",
        "/var/lib/docker",
        "/var/run/docker.sock",
        "/etc/kubernetes",
        "/proc/1/root",
        "/etc/shadow",
        "/etc/passwd"
    ]

    # Normalize custom paths
    paths_to_check = list(set(custom_paths)) if custom_paths else default_paths

    escape_keywords = ["bash", "sh", "passwd", "shadow", "sudo", "hostPath", "cgroup"]

    for path in paths_to_check:
        if os.path.exists(path):
            print(f"{path} (exists)")
            try:
                if os.path.isfile(path):
                    size = os.path.getsize(path)
                    ctime = datetime.fromtimestamp(os.path.getctime(path)).isoformat()
                    print(f"  File size: {size} bytes")
                    print(f"  Created: {ctime}")
                    with open(path, 'r', errors='ignore') as f:
                        print("  Preview:")
                        for i, line in enumerate(f):
                            print(f"    {line.strip()}")
                            if any(keyword in line for keyword in escape_keywords):
                                print("    [!] Potential escape keyword found")
                            if i == 4:
                                print("    ... (truncated)")
                                break
                elif os.path.isdir(path):
                    entries = os.listdir(path)
                    print("  Directory contents:")
                    for entry in entries[:5]:
                        print(f"    - {entry}")
                        if any(keyword in entry for keyword in escape_keywords):
                            print("    [!] Potential escape keyword found")
                    if len(entries) > 5:
                        print("    ... (truncated)")
            except Exception as e:
                print(f"  Failed to read: {e}")
        else:
            print(f"{path} does not exist")
