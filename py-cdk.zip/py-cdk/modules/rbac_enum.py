# modules/rbac_enum.py
from kubernetes import client, config

def list_rbac():
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        rbac_api = client.RbacAuthorizationV1Api()
        core_api = client.CoreV1Api()

        print("Service Accounts:")
        for sa in core_api.list_service_account_for_all_namespaces().items:
            print(f"  {sa.metadata.namespace}/{sa.metadata.name}")

        print("\nRoles:")
        for role in rbac_api.list_role_for_all_namespaces().items:
            print(f"  {role.metadata.namespace}/{role.metadata.name}")

        print("\nRoleBindings:")
        for rb in rbac_api.list_role_binding_for_all_namespaces().items:
            print(f"  {rb.metadata.namespace}/{rb.metadata.name}")

        print("\nClusterRoles:")
        for cr in rbac_api.list_cluster_role().items:
            print(f"  {cr.metadata.name}")

        print("\nClusterRoleBindings:")
        for crb in rbac_api.list_cluster_role_binding().items:
            print(f"  {crb.metadata.name}")

    except Exception as e:
        print(f"Failed to enumerate RBAC resources: {e}")
