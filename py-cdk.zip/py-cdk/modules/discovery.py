def run_discovery(full=False):
    """Run a suite of discovery modules to audit the Kubernetes environment."""
    print("\n[+] Gathering Node Info...")
    from modules.nodes_enum import list_nodes
    list_nodes()

    print("\n[+] Checking Container Capabilities...")
    from modules.kube_enum import list_container_capabilities
    list_container_capabilities()

    print("\n[+] Checking Mounted Volumes...")
    from modules.volumes_enum import list_mounted_volumes
    list_mounted_volumes()

    print("\n[+] Gathering Secrets...")
    from modules.secrets_enum import list_secrets
    list_secrets(namespace=None, decode=False, type_filter=None, show_age=True)

    print("\n[+] Enumerating Service Account Tokens...")
    from modules.tokens_enum import list_service_account_tokens
    list_service_account_tokens()

    print("\n[+] Mapping Services and Endpoints...")
    from modules.network_enum import list_services_and_endpoints
    list_services_and_endpoints()

    if full:
        try:
            from modules.cloud_enum import probe_metadata_endpoint
            print("\n[+] Probing Cloud Metadata Endpoint...")
            probe_metadata_endpoint()
        except ImportError:
            print("[!] Cloud metadata module not available.")

        try:
            from modules.local_enum import run_full_local_checks
            print("\n[+] Running Full Local Evaluation...")
            run_full_local_checks()
        except ImportError:
            print("[!] Local evaluation module not available.")

    print("\n[+] Available Exploits:")
    from modules.exploits_registry import list_available_exploits
    list_available_exploits()


def evaluate(full=False):
    """Alias for run_discovery for user-friendly CLI."""
    run_discovery(full=full)
