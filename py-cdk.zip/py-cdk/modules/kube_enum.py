# modules/kube_enum.py
from kubernetes import client, config
from tabulate import tabulate
from modules.privileged_pods import list_privileged_pods

def list_all_pods(namespace=None, status=None, show_ip=False, show_image=False):
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()

        if namespace:
            pods = v1.list_namespaced_pod(namespace).items
        else:
            pods = v1.list_pod_for_all_namespaces().items

        print("Listing all pods in all namespaces:\n")
        for pod in pods:
            pod_name = pod.metadata.name
            pod_ns = pod.metadata.namespace
            pod_status = pod.status.phase

            if status and status.lower() != pod_status.lower():
                continue

            node_name = pod.spec.node_name
            line = f"{pod_ns} - {pod_name} (Node: {node_name})"

            if show_ip:
                pod_ip = pod.status.pod_ip
                line += f" | IP: {pod_ip}"

            if show_image:
                images = [c.image for c in pod.spec.containers]
                line += f" | Images: {', '.join(images)}"

            print(line)

    except Exception as e:
        print(f"Error listing pods: {e}")

def list_container_capabilities(only_privileged=False):
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()
        outputlist = []
        ret = v1.list_pod_for_all_namespaces(watch=False)

        for i in ret.items:
            for j in i.spec.containers:
                caps = "NoCapsAdded"
                if j.security_context:
                    if j.security_context.capabilities and j.security_context.capabilities.add:
                        caps = ", ".join(j.security_context.capabilities.add)
                privileged = "Yes" if j.security_context and j.security_context.privileged else "No"

                if only_privileged and privileged != "Yes":
                    continue

                outputlist.append([
                    j.name,
                    i.metadata.name,
                    i.metadata.namespace,
                    privileged,
                    caps
                ])

        print("\nContainer Capabilities and Privileged Mode:")
        print(tabulate(outputlist, headers=["Container", "Pod", "Namespace", "Privileged", "Capabilities"]))

    except Exception as e:
        print(f"Error retrieving container capabilities: {e}")

def privileged_pods(export=False):
    list_privileged_pods(export_csv=export)

# CLI integration
import click

@click.command(name="privileged-pods")
@click.option('--export', is_flag=True, help='Export results to privilegedContainers.csv')
def cli_privileged_pods(export):
    """List containers running with privileged securityContext"""
    privileged_pods(export=export)
