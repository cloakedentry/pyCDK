# modules/configmap_enum.py
from kubernetes import client, config

def list_configmaps(namespace=None):
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()

        if namespace:
            configmaps = v1.list_namespaced_config_map(namespace=namespace).items
            print(f"Listing ConfigMaps in namespace '{namespace}':\n")
        else:
            configmaps = v1.list_config_map_for_all_namespaces().items
            print("Listing all ConfigMaps in the cluster:\n")

        for cm in configmaps:
            print(f"{cm.metadata.namespace}/{cm.metadata.name}")
            if cm.data:
                for key, val in cm.data.items():
                    print(f"  {key}: {val[:60]}{'...' if len(val) > 60 else ''}")
            else:
                print("  (empty configmap)")
            print()

    except Exception as e:
        print(f"Failed to list ConfigMaps: {e}")
