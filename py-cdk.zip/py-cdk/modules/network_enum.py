# modules/network_enum.py
from kubernetes import client, config

def list_services_and_endpoints():
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()
        services = v1.list_service_for_all_namespaces().items
        endpoints = v1.list_endpoints_for_all_namespaces().items

        print("Services:")
        for svc in services:
            name = svc.metadata.name
            ns = svc.metadata.namespace
            cluster_ip = svc.spec.cluster_ip
            ports = ", ".join([f"{p.port}/{p.protocol}" for p in svc.spec.ports])
            print(f"{ns}/{name} - {cluster_ip} - Ports: {ports}")

        print("\nEndpoints:")
        for ep in endpoints:
            name = ep.metadata.name
            ns = ep.metadata.namespace
            for subset in ep.subsets or []:
                addresses = [addr.ip for addr in subset.addresses or []]
                ports = [str(p.port) for p in subset.ports or []]
                print(f"{ns}/{name} - IPs: {', '.join(addresses)} - Ports: {', '.join(ports)}")

    except Exception as e:
        print(f"Error listing services/endpoints: {e}")
