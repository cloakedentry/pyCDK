# modules/evaluation.py
import os
import stat
import psutil
import subprocess

PATH_SEVERITY = {
    "/etc/shadow": "HIGH",
    "/etc/passwd": "MEDIUM",
    "/var/run/docker.sock": "HIGH",
    "/proc/1/root": "HIGH",
    "/host": "HIGH",
    "/etc/kubernetes": "MEDIUM",
}

RISK_SCORE = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}

def check_sensitive_envs():
    findings = []
    for k, v in os.environ.items():
        if any(secret in k.lower() for secret in ["token", "secret", "key", "passwd"]):
            findings.append(("HIGH", f"Env Var: {k}={v}"))
    return findings

def check_sensitive_paths(severity_map):
    findings = []
    for path, severity in severity_map.items():
        if os.path.exists(path):
            findings.append((severity, f"File/Path: {path}"))
    return findings

def evaluate_capabilities():
    findings = []
    try:
        with open("/proc/self/status") as f:
            for line in f:
                if line.startswith("CapEff"):
                    capabilities = line.split()[1]
                    if capabilities != "0000000000000000":
                        findings.append(("HIGH", "Capability: CAP_SYS_ADMIN\n    \u21aa Detected potentially dangerous capability"))
    except Exception as e:
        findings.append(("LOW", f"Error evaluating capabilities: {e}"))
    return findings

def evaluate_privileged_containers():
    findings = []
    try:
        with open("/proc/1/status") as f:
            lines = f.read()
            if "Uid:\t0\t0\t0\t0" in lines:
                findings.append(("HIGH", "Container running as UID 0\n    \u21aa Potential privilege escalation"))
    except:
        pass
    return findings

def evaluate_kernel_config():
    findings = []
    try:
        output = subprocess.check_output(["uname", "-a"]).decode().strip()
        if "k3s" in output or "generic" in output:
            findings.append(("MEDIUM", f"Kernel config: {output}"))
    except Exception as e:
        findings.append(("LOW", f"Error inspecting kernel: {e}"))
    return findings

def evaluate_writable_paths():
    sensitive = ["/etc/shadow", "/etc/passwd", "/root", "/host"]
    findings = []
    for path in sensitive:
        if os.path.exists(path) and os.access(path, os.W_OK):
            findings.append(("HIGH", f"Writable Path: {path}\n    \u21aa Writable sensitive file or directory"))
    return findings

def evaluate_running_services():
    findings = []
    for proc in psutil.process_iter(attrs=["pid", "name", "cmdline"]):
        try:
            name = proc.info["name"] or ""
            cmd = " ".join(proc.info["cmdline"] or [])
            if any(k in cmd.lower() for k in ["ssh", "ftp", "telnet"]):
                findings.append(("MEDIUM", f"Service: {name} - {cmd}"))
        except:
            continue
    return findings

def format_findings(findings):
    for level, msg in findings:
        print(f"- [{level}] {msg}")

def summarize_findings(findings):
    summary = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for level, _ in findings:
        if level in summary:
            summary[level] += 1
    print("\n--- Risk Summary ---")
    for level in ["HIGH", "MEDIUM", "LOW"]:
        print(f"{level}: {summary[level]}")

def run_evaluation(full=False):
    all_findings = []
    all_findings += check_sensitive_envs()
    all_findings += check_sensitive_paths(PATH_SEVERITY)
    all_findings += evaluate_capabilities()
    all_findings += evaluate_privileged_containers()

    if full:
        all_findings += evaluate_kernel_config()
        all_findings += evaluate_writable_paths()
        all_findings += evaluate_running_services()

    format_findings(all_findings)
    summarize_findings(all_findings)
    return all_findings
