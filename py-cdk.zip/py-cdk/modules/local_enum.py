# modules/local_enum.py

import os

def run_full_local_checks():
    print("[*] Checking environment variables...")
    for k, v in os.environ.items():
        print(f"  {k}={v}")

    print("\n[*] Checking common sensitive files...")
    sensitive_files = ["/etc/passwd", "/etc/shadow", "/root/.bash_history"]
    for f in sensitive_files:
        if os.path.exists(f):
            print(f"  [+] Found: {f}")
        else:
            print(f"  [-] Not found: {f}")
