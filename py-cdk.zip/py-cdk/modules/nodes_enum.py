# modules/nodes_enum.py
from kubernetes import client, config

def list_nodes():
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()
        nodes = v1.list_node().items

        for node in nodes:
            name = node.metadata.name
            print(f"\nNode: {name}")

            print("  Labels:")
            for key, value in node.metadata.labels.items():
                print(f"    {key}: {value}")

            taints = node.spec.taints or []
            if taints:
                print("  Taints:")
                for t in taints:
                    print(f"    {t.key}={t.value}:{t.effect}")
            else:
                print("  Taints: None")

            info = node.status.node_info
            print("  System Info:")
            print(f"    OS Image: {info.os_image}")
            print(f"    Kernel Version: {info.kernel_version}")
            print(f"    Kubelet Version: {info.kubelet_version}")
            print(f"    Container Runtime Version: {info.container_runtime_version}")

    except Exception as e:
        print(f"Failed to list nodes: {e}")