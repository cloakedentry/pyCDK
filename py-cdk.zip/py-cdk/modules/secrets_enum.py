# modules/secrets_enum.py
from kubernetes import client, config
import base64
from datetime import datetime

def list_secrets(namespace=None, decode=False, type_filter=None, show_age=False):
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()

        if namespace:
            secrets = v1.list_namespaced_secret(namespace).items
        else:
            secrets = v1.list_secret_for_all_namespaces().items

        for secret in secrets:
            ns = secret.metadata.namespace
            name = secret.metadata.name
            sec_type = secret.type

            if type_filter and sec_type != type_filter:
                continue

            print(f"{ns}/{name} (type: {sec_type})")

            if show_age:
                timestamp = secret.metadata.creation_timestamp
                print(f"  Created: {timestamp}")

            if decode and secret.data:
                for key, val in secret.data.items():
                    try:
                        decoded = base64.b64decode(val).decode("utf-8")
                        print(f"  {key}: {decoded}")
                    except Exception as e:
                        print(f"  {key}: <decode error: {e}>")
            print()

    except Exception as e:
        print(f"Error listing secrets: {e}")
