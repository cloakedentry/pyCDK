# modules/tools/tool_ps.py
import psutil

def run_ps():
    print("\n[+] Running ps-like process listing:\n")
    for proc in psutil.process_iter(['pid', 'name', 'username']):
        print(f"{proc.info['pid']:>6} {proc.info['username']:<15} {proc.info['name']}")
