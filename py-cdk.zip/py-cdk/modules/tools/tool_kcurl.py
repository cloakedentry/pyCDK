import requests
import os

def run_kcurl():
    token_path = '/var/run/secrets/kubernetes.io/serviceaccount/token'
    ca_cert_path = '/var/run/secrets/kubernetes.io/serviceaccount/ca.crt'
    api_server = os.environ.get('KUBERNETES_SERVICE_HOST', 'kubernetes.default.svc')
    api_port = os.environ.get('KUBERNETES_SERVICE_PORT', '443')
    url = f"https://{api_server}:{api_port}/api"

    try:
        with open(token_path, 'r') as f:
            token = f.read().strip()

        headers = {'Authorization': f'Bearer {token}'}
        response = requests.get(url, headers=headers, verify=ca_cert_path)
        print("[+] Kubernetes API Server Response:")
        print(response.text)
    except Exception as e:
        print(f"[!] Failed to connect to Kubernetes API: {e}")
