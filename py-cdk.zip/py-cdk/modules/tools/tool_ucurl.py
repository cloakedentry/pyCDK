import socket
import json
import http.client

def run_ucurl(method, socket_path, uri, data=None):
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.connect(socket_path)
        conn = http.client.HTTPConnection('localhost')
        conn.sock = sock

        headers = {'Content-Type': 'application/json'}
        if method == "get":
            conn.request("GET", uri, headers=headers)
        elif method == "post":
            conn.request("POST", uri, body=data or "", headers=headers)

        response = conn.getresponse()
        body = response.read().decode()

        print(f"[+] Status: {response.status} {response.reason}")
        print(f"[+] Headers: {dict(response.getheaders())}")
        print("[+] Body:")
        print(body)
        conn.close()

    except Exception as e:
        print(f"[!] Error communicating with socket: {e}")
