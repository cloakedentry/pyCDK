import psutil
import socket

def run_ifconfig():
    print("\n[+] Network Interface Configuration:\n")
    interfaces = psutil.net_if_addrs()
    stats = psutil.net_if_stats()

    for iface, addrs in interfaces.items():
        print(f"Interface: {iface}")
        is_up = stats[iface].isup
        mtu = stats[iface].mtu
        print(f"  Status: {'UP' if is_up else 'DOWN'}")
        print(f"  MTU: {mtu}")
        for addr in addrs:
            if addr.family == socket.AF_INET:
                print(f"  IPv4 Address: {addr.address}")
                print(f"  Netmask: {addr.netmask}")
            elif addr.family == socket.AF_INET6:
                print(f"  IPv6 Address: {addr.address}")
            elif addr.family == psutil.AF_LINK:
                print(f"  MAC Address: {addr.address}")
        print()
