import requests

def run_ectl(host='127.0.0.1', port=None):
    import requests
    from urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

    default_ports = [2379, 4001] if not port else [int(port)]

    for p in default_ports:
        url = f"http://{host}:{p}/v2/keys/"
        print(f"[+] Trying etcd endpoint: {url}")
        try:
            response = requests.get(url, timeout=3)
            if response.status_code == 200:
                print("[+] Successfully accessed etcd endpoint:")
                print(response.text)
                return
            else:
                print(f"[!] Unexpected status code {response.status_code}")
        except Exception as e:
            print(f"[!] Error accessing {url}: {e}")
