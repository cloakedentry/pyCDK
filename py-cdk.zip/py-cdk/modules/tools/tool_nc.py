import socket
import threading

def forward(src, dst):
    while True:
        try:
            data = src.recv(4096)
            if not data:
                break
            dst.sendall(data)
        except Exception:
            break
    src.close()
    dst.close()

def run_nc(lport, rhost, rport):
    print(f"[+] Listening on 0.0.0.0:{lport} and tunneling to {rhost}:{rport}")
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    listener.bind(("0.0.0.0", lport))
    listener.listen(5)

    while True:
        client_socket, addr = listener.accept()
        print(f"[+] Connection from {addr}")

        remote_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            remote_socket.connect((rhost, rport))
        except Exception as e:
            print(f"[!] Failed to connect to remote {rhost}:{rport} - {e}")
            client_socket.close()
            continue

        threading.Thread(target=forward, args=(client_socket, remote_socket), daemon=True).start()
        threading.Thread(target=forward, args=(remote_socket, client_socket), daemon=True).start()
