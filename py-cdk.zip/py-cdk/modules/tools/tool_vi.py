# modules/tools/vi.py

def main(filename=None):
    if not filename:
        print("[!] Usage: vi <filename>")
        return
    print(f"[+] Simulating vi opening file: {filename}")
    try:
        with open(filename, 'r') as f:
            print(f.read())
    except Exception as e:
        print(f"[!] Failed to open {filename}: {e}")
