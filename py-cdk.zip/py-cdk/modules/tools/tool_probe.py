# modules/tools/tool_probe.py
import socket
import ipaddress
import concurrent.futures
import re

def parse_ip_range(ip_range_str):
    match = re.match(r"(\d+\.\d+\.\d+)\.(\d+)-(\d+)", ip_range_str)
    if not match:
        return [ip_range_str]
    base, start, end = match.groups()
    return [f"{base}.{i}" for i in range(int(start), int(end) + 1)]

def parse_ports(port_str):
    ports = set()
    for part in port_str.split(','):
        if '-' in part:
            start, end = map(int, part.split('-'))
            ports.update(range(start, end + 1))
        else:
            ports.add(int(part))
    return sorted(ports)

def scan_target(ip, port, timeout):
    try:
        with socket.create_connection((ip, port), timeout=timeout / 1000):
            return ip, port, True
    except:
        return ip, port, False

def run_probe(ip_range, ports, parallel, timeout):
    targets = [(ip, port) for ip in parse_ip_range(ip_range) for port in parse_ports(ports)]
    print(f"[+] Scanning {len(targets)} targets with {parallel} workers and {timeout}ms timeout\n")

    with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as executor:
        futures = {executor.submit(scan_target, ip, port, timeout): (ip, port) for ip, port in targets}
        for future in concurrent.futures.as_completed(futures):
            ip, port = futures[future]
            try:
                ip, port, open_ = future.result()
                if open_:
                    print(f"[+] Open: {ip}:{port}")
            except Exception as e:
                print(f"[!] Error scanning {ip}:{port} - {e}")
