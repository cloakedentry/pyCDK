# modules/etcd_enum.py
import requests

def check_etcd_access(host="localhost", port=2379):
    url = f"http://{host}:{port}/v2/keys/"
    try:
        print(f"Trying to access etcd at {url}\n")
        response = requests.get(url, timeout=5)
        if response.status_code == 200:
            print("etcd is accessible and responding with data:\n")
            print(response.text)
        elif response.status_code == 403:
            print("etcd is reachable but access is forbidden (403).")
        elif response.status_code == 404:
            print("etcd is reachable but key not found (404).")
        else:
            print(f"etcd responded with status code {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Failed to connect to etcd: {e}")