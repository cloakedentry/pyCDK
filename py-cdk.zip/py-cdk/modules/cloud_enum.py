# modules/cloud_enum.py

import requests

def probe_metadata_endpoint():
    endpoints = [
        "http://169.254.169.254/latest/meta-data/",
        "http://169.254.169.254/metadata/instance",
    ]
    for url in endpoints:
        try:
            response = requests.get(url, timeout=2)
            if response.status_code == 200:
                print(f"[✓] Found metadata at: {url}")
                return
        except requests.exceptions.RequestException:
            continue
    print("[!] Metadata endpoint not accessible or not present.")
