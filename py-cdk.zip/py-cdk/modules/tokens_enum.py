# modules/tokens_enum.py
import base64
from kubernetes import client, config

def list_service_account_tokens():
    try:
        try:
            config.load_incluster_config()
        except:
            config.load_kube_config()

        v1 = client.CoreV1Api()
        secrets = v1.list_secret_for_all_namespaces()

        print("Searching for service account tokens...\n")

        for secret in secrets.items:
            if secret.type == "kubernetes.io/service-account-token":
                name = secret.metadata.name
                namespace = secret.metadata.namespace
                token_b64 = secret.data.get("token")
                if token_b64:
                    try:
                        token = base64.b64decode(token_b64).decode("utf-8")
                        print(f"{namespace}/{name}:")
                        print(f"  Token: {token[:60]}...\n")
                    except Exception as decode_err:
                        print(f"  Failed to decode token: {decode_err}\n")
    except Exception as e:
        print(f"Error while listing tokens: {e}")