# main.py
import click
from modules.kube_enum import list_all_pods, list_container_capabilities
from modules.container_escape import check_escape_method
from modules.secrets_enum import list_secrets
from modules.nodes_enum import list_nodes
from modules.rbac_enum import list_rbac
from modules.configmap_enum import list_configmaps
from modules.tokens_enum import list_service_account_tokens
from modules.etcd_enum import check_etcd_access
from modules.reverse_shell import generate_reverse_shell, execute_reverse_shell
from modules.network_enum import list_services_and_endpoints
from modules.volumes_enum import list_mounted_volumes
from modules.privileged_pods import list_privileged_pods
from modules.discovery import run_discovery
from modules.evaluation import (
    run_evaluation,
    check_sensitive_envs,
    check_sensitive_paths,
    evaluate_capabilities,
    evaluate_privileged_containers,
    evaluate_kernel_config,
    evaluate_writable_paths,
    evaluate_running_services,
    format_findings,
    summarize_findings
)
from modules.tools_registry import list_available_tools

PATH_SEVERITY = {
    "/etc/shadow": "HIGH",
    "/etc/passwd": "MEDIUM",
    "/var/run/docker.sock": "HIGH",
    "/proc/1/root": "HIGH",
    "/host": "HIGH",
    "/etc/kubernetes": "MEDIUM",
}

@click.group()
def cli():
    """pyCDK - Dependency Container Toolkit (Python Version)"""
    pass

@cli.command()
@click.option('--namespace', '-n', default=None, help='Namespace to filter pods')
@click.option('--status', '-s', default=None, help='Filter pods by status (e.g., Running, Pending)')
@click.option('--show-ip', is_flag=True, help='Show pod IP addresses')
@click.option('--show-image', is_flag=True, help='Show container images used in pods')
def pods(namespace, status, show_ip, show_image):
    list_all_pods(namespace, status, show_ip, show_image)

@cli.command()
@click.option('--only-privileged', is_flag=True, help='Only show containers running in privileged mode')
def caps(only_privileged):
    """Show Linux capabilities and privilege mode for all containers"""
    list_container_capabilities(only_privileged=only_privileged)

@cli.command(name="pp", help="Alias for privileged-pods")
@click.option('--namespace', '-n', default=None, help='Namespace to filter for privileged pods')
@click.option('--export', is_flag=True, help='Export results to privilegedContainers.csv')
@click.option('--show-risk', is_flag=True, help='Include risk level column')
@click.option('--show-image', is_flag=True, help='Include container image column')
def privileged_pods_cmd(namespace, export, show_risk, show_image):
    list_privileged_pods(export_csv=export, namespace=namespace, show_risk=show_risk, show_image=show_image)

@cli.command()
@click.option('--method', '-m', default='hostpath', help='Escape method to check (e.g., hostpath, cgroup, proc)')
def escape(method):
    check_escape_method(method)

@cli.command()
@click.option('--namespace', '-n', default=None, help='Namespace to filter secrets')
@click.option('--decode', is_flag=True, help='Decode secret values from base64')
@click.option('--type', '-t', default=None, help='Filter secrets by type (e.g., Opaque, kubernetes.io/tls)')
@click.option('--show-age', is_flag=True, help='Show creation timestamps of secrets')
def secrets(namespace, decode, type, show_age):
    list_secrets(namespace, decode, type, show_age)

@cli.command()
def nodes():
    list_nodes()

@cli.command()
def rbac():
    list_rbac()

@cli.command()
@click.option('--namespace', '-n', default=None, help='Namespace to filter configmaps')
def configmaps(namespace):
    list_configmaps(namespace)

@cli.command()
def tokens():
    list_service_account_tokens()

@cli.command()
@click.option('--host', default='localhost', help='etcd host IP')
@click.option('--port', default=2379, help='etcd port')
def etcd(host, port):
    check_etcd_access(host, port)

@cli.command(name='reverse-shell')
@click.option('--generate', is_flag=True, help='Only generate a reverse shell command')
@click.option('--ip', required=True, help='Attacker IP')
@click.option('--port', required=True, help='Attacker port')
def reverse_shell(generate, ip, port):
    if generate:
        generate_reverse_shell(ip, port)
    else:
        execute_reverse_shell(ip, port)

@cli.command()
def network():
    list_services_and_endpoints()

@cli.command()
@click.option('--path', '-p', multiple=True, help='Custom path(s) to inspect (can be used multiple times)')
def volumes(path):
    print("\n--- Volume Severity Report ---")
    for p in path:
        severity = PATH_SEVERITY.get(p, "LOW")
        print(f"Path: {p} - Severity: {severity}")
    print("\n--- Volume Content Scan ---")
    list_mounted_volumes(custom_paths=path)

@cli.command()
@click.option('--full', is_flag=True, help='Run full discovery including cloud metadata check')
def discover(full):
    run_discovery(full=full)

@cli.command(name="evaluate")
@click.option('--full', is_flag=True, help='Enable full evaluation (e.g., ENV, sensitive files, risk scoring)')
def evaluate_cmd(full):
    all_findings = []

    click.echo("[+] Evaluating sensitive environment variables...")
    all_findings += check_sensitive_envs()

    click.echo("[+] Checking for sensitive mount paths...")
    all_findings += check_sensitive_paths(PATH_SEVERITY)

    click.echo("[+] Evaluating Linux capabilities and privilege escalation vectors...")
    all_findings += evaluate_capabilities()

    click.echo("[+] Checking for privileged containers...")
    all_findings += evaluate_privileged_containers()

    if full:
        click.echo("[+] Inspecting kernel configurations...")
        all_findings += evaluate_kernel_config()

        click.echo("[+] Checking for writable sensitive files or directories...")
        all_findings += evaluate_writable_paths()

        click.echo("[+] Reviewing running processes and services...")
        all_findings += evaluate_running_services()

    click.echo("\n--- Evaluation Report ---")
    format_findings(all_findings)
    summarize_findings(all_findings)

@cli.command(name="run")
@click.option('--list', 'list_exploits', is_flag=True, help="List all available exploits")
@click.argument('exploit', required=False)
@click.argument('args', nargs=-1)
def run_exploit(list_exploits, exploit, args):
    if list_exploits:
        from modules.exploits_registry import list_available_exploits
        list_available_exploits()
        return

    if not exploit:
        click.echo("[!] No exploit specified. Use --list to see available exploits.")
        return

    try:
        module = __import__(f"modules.exploits.{exploit.replace('-', '_')}", fromlist=['run'])
        module.run(*args)
    except ModuleNotFoundError:
        click.echo(f"[!] Exploit '{exploit}' not found.")
    except AttributeError:
        click.echo(f"[!] Exploit '{exploit}' does not have a run() function.")

@cli.group()
def tool():
    """Run built-in tools like vi, ps, kcurl, etc."""
    pass

@tool.command("list")
def list_tools_cmd():
    list_available_tools()

@tool.command()
def ifconfig():
    from modules.tools.tool_ifconfig import run_ifconfig
    run_ifconfig()

@tool.command()
def ps():
    from modules.tools.tool_ps import run_ps
    run_ps()

@tool.command()
def kcurl():
    from modules.tools.tool_kcurl import run_kcurl
    run_kcurl()

@tool.command()
@click.option('--host', default='127.0.0.1', help='etcd host IP (default: 127.0.0.1)')
@click.option('--port', default=None, help='Custom etcd port (optional)')
def ectl(host, port):
    from modules.tools.tool_ectl import run_ectl
    run_ectl(host, port)

@tool.command()
@click.argument('method', type=click.Choice(['get', 'post'], case_sensitive=False))
@click.argument('socket_path')
@click.argument('uri')
@click.argument('data', required=False)
def ucurl(method, socket_path, uri, data):
    from modules.tools.tool_ucurl import run_ucurl
    run_ucurl(method, socket_path, uri, data)

@tool.command()
@click.option('--lport', required=True, type=int, help='Local port to listen on')
@click.option('--rhost', required=True, help='Remote host to forward to')
@click.option('--rport', required=True, type=int, help='Remote port to forward to')
def nc(lport, rhost, rport):
    from modules.tools.tool_nc import run_nc
    run_nc(lport, rhost, rport)

if __name__ == '__main__':
    cli()
